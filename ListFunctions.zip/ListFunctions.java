import java.util.function.BiFunction;

import tester.Tester;

interface IFunc<Arg, Ret> {
  Ret apply(Arg t);
}


class SquareNum implements IFunc<Double, Double> {
  public Double apply(Double t) {
    return t * t;
  }
}

class SineNum implements IFunc<Double, Double> {
  public Double apply(Double t) {
    return Math.sin(t);
  }
}

class Identity<T> implements IFunc<T, T> {
  public T apply(T t) {
    return t;
  }
}

class PlusN implements IFunc<Double, Double> {
  Double n;

  PlusN(Double n) {
    this.n = n;
  }

  //
  public Double apply(Double t) {
    return t + n;
  }
}
//f(x) = (sin(x) + 1)^2
class FunctionComposition<Arg, Mid, Ret> implements IFunc<Arg, Ret> {
  private final IFunc<Arg, Mid> func1;
  private final IFunc<Mid, Ret> func2;

  FunctionComposition(IFunc<Arg, Mid> func1, IFunc<Mid, Ret> func2) {
    this.func1 = func1;
    this.func2 = func2;
  }

  public Ret apply(Arg t) {
    Mid that = this.func1.apply(t);
    return this.func2.apply(that);
  }
}


interface IFunc2<Arg1, Arg2, Ret> {

  Ret apply(Arg1 arg1, Arg2 arg2);
}

/*
 * This means the first input represents an f(x) function that takes in an x and outputs a
 * y. The second input takes in a y and outputs a z. The returning function takes in an x
 * and outputs a z, which essentially applies the second function to the first. This differs from 
 * FunctionCommposition as FunctionComposition requires you to an x initially which would output a y 
 * to produce a function that requires an additional input of y to get to z. On the other hand, 
 * ComposeFunctions only takes in a x which produces a y, which is then taken in by the returning 
 * function which takes in a x to produce a z. The main difference is that  FunctionnComposition 
 * ultimately return a the number produced by nesting the first function inside the 
 * second as it's input. However, the Composition Function returns a function instead of a number, 
 * the function being the first function nested inside the second as its input. 
 */
class ComposeFunctions<Arg1, Arg2, Ret> 
implements IFunc2<IFunc<Arg1, Arg2>, IFunc<Arg2, Ret>, IFunc<Arg1, Ret>> {

  public IFunc<Arg1, Ret> apply(IFunc<Arg1, Arg2> func1, IFunc<Arg2, Ret> func2) {
    return new FunctionComposition<Arg1, Arg2, Ret>(func1, func2);
  }
}

interface IList<T> {
  <U> U foldL(IFunc2<T, U, U> converter, U initial);
}

class MtList<T> implements IList<T> {
  //returns the empty list 
  public <U> U foldL(IFunc2<T, U, U> converter, U initial) {
    return initial;
}
}

class ConsList<T> implements IList<T> {
  T first;
  IList<T> rest;
  
  ConsList(T first, IList<T> rest) {
    this.first = first;
    this.rest = rest;
  }
  
  //
  public <U> U foldL(IFunc2<T, U, U> converter, U initial) {
    return this.rest.foldL(converter, converter.apply(this.first, initial)); //where is apply written
  }
}

//since we haven't implemented any "same" or .equals method to compare the two
//methods in the check expect, the check expect cannot tell you that they are the same,
//so they will directly compare the input and the output word for word, which will
//yield a false because the input and output are not directly the same


